﻿function findGame() {

    //get game code
    var gamecodeFromTxt = $("#gameCodeTxt").val();

    //call to handler
    $.get("Handler.ashx", {
        gameCode: gamecodeFromTxt //sent game code
    },
    function (data, status) {

        if (status == "success") {

            //printing  the response in the console
            console.log(data);

            //if game not found or not publish
            if (data == "המשחק קיים אך לא מפורסם" || data == "לא נמצא משחק") {

                //printing the message to the screen
                $("#feedback").html(data);
            }
            else {
                //convert response to json format
                obj = JSON.parse(data);

                //printing the game name
                $("#feedback").html(obj.gameName);
            }
        }
    });

}